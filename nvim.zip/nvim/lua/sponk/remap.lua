vim.g.mapleader = " "

-- normal mode
vim.keymap.set("n", "<leader>pv", vim.cmd.Ex)
