require("sponk.remap")

vim.o.syntax = "on"
vim.o.mouse = 'a'  	     -- allow mouse usage in all modes
vim.o.number = true          -- show line numbers
vim.o.hlsearch = true        -- highlight searched word
vim.o.wrap = false           -- don't wrap lines
vim.o.incsearch = true       -- highlight while typing
vim.o.shiftround = true      -- round indents to multiple of shiftwidth
vim.o.tabstop = 4            -- spaces per tab
vim.o.softtabstop = 4        -- spaces per tab while editing
vim.o.shiftwidth = 4         -- spaces per shift
vim.o.expandtab = true       -- tabs are spaces
vim.o.linebreak = true       -- avoid wrapping a line in the middle of a word
vim.o.ruler = true           -- show column number bottom right
vim.o.swapfile = false       -- no swapfiles
vim.o.cursorline = true      -- highlight the current line
vim.o.cindent = true
vim.o.autoindent = true      -- try best to indent
vim.o.backup = false         -- no backup files
vim.o.history = 300          -- vim history
vim.o.backspace = "indent,eol,start"
vim.o.smartcase = true       -- case-sensitive only when query contains uppercase letter
vim.o.ignorecase = true

-- Prevent { and } from affecting the jumplist
vim.api.nvim_set_keymap('n', '}', ':keepjumps normal! }<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '{', ':keepjumps normal! {<CR>', { noremap = true, silent = true })

if vim.o.encoding == 'latin1' and vim.fn.has('gui_running') == 1 then
  vim.o.encoding = 'utf-8'
end
