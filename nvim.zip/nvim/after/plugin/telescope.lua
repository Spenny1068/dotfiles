local builtin = require('telescope.builtin')

vim.keymap.set('n', '<leader>f', builtin.find_files, {}) 	-- find in "all files"
vim.keymap.set('n', '<leader>pf', builtin.git_files, {}) 	-- find in "git files"
vim.keymap.set('n', '<leader>s', function()  			-- grep
	local search_term = vim.fn.input("Grep > ")
	builtin.grep_string({ search = search_term });
end)

