local builtin = require('telescope.builtin')

vim.keymap.set('n', '<leader>f', builtin.find_files, {}) 	-- find in "all files"
vim.keymap.set('n', '<leader>pf', builtin.git_files, {}) 	-- find in "git files"

-- manual grep (no exact word match)
vim.keymap.set('n', '<leader>s', function()  			    
	local search_term = vim.fn.input("Grep > ")
	builtin.grep_string({ search = search_term });
end)

-- manual grep (exact word match)
vim.keymap.set('n', '<leader>S', function()  			    
    local search_term = vim.fn.input("Grep > ")
    require('telescope.builtin').grep_string({ 
        search = search_term,
        additional_args = function() return { "-w" } end,
    })
end, { desc = "Manual Grep (exact word match)" })

-- grep word under cursor 
vim.keymap.set('n', '<leader>*', function()
    require('telescope.builtin').grep_string({
        search = vim.fn.expand("<cword>"),
        additional_args = function() return { "-w" } end,
    })
end, { desc = "Grep word under cursor (exact match)" })
