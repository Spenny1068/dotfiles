// where to put init.lua: run this inside nvim
:echo stdpath("config")

// install packer (unix)
git clone --depth 1 https://github.com/wbthomason/packer.nvim\
 ~/.local/share/nvim/site/pack/packer/start/packer.nvim

// packer
:PackerSync

// if <leader>s not working as expected:
sudo apt install ripgrep

nvim
- README.txt
- init.lua
- after
   - plugin
      - telescope.lua
      - colors.lua
- lua
   - sponk
      - init.lua
      - packer.lua
      - remap.lua
- plugin
   - packer_compiled.lua
